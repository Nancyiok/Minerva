﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using Newtonsoft.Json;
using System.Security.Policy;

namespace TestMinervaServer
{
    internal class Program
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("1 - авторизация пользователя");
            Console.WriteLine("2 - регистрация пользователя");
            string inform = Console.ReadLine();
            if (inform == "1")
            {
                Console.WriteLine("Введите email пользователя");
                string Email = Console.ReadLine();

                var httpClient = new HttpClient();

                var loginRequest = new
                {
                    email = Email,
                    password = "55555"
                };

                var jsonContent = new StringContent(JsonConvert.SerializeObject(loginRequest), Encoding.UTF8, "application/json");

                var response = await httpClient.PostAsync("http://localhost:5145/api/auth/login", jsonContent);

                var responseString = await response.Content.ReadAsStringAsync();

                Console.WriteLine($"Response Status: {response.StatusCode}");
                Console.WriteLine($"Response Content: {responseString}");
            }
            else if (inform == "2") 
            {
                Console.WriteLine("Введите Username пользователя");
                string name = Console.ReadLine();

                Console.WriteLine("Введите Password пользователя");
                string password = Console.ReadLine();

                Console.WriteLine("Введите email пользователя");
                string Email = Console.ReadLine();

                Console.WriteLine("Введите phone пользователя");
                string Phone = Console.ReadLine();

                var httpClient = new HttpClient();

                var loginRequest = new
                {
                    Username = name,
                    Password = password,
                    email = Email,
                };

                var jsonContent = new StringContent(JsonConvert.SerializeObject(loginRequest), Encoding.UTF8, "application/json");

                var response = await httpClient.PostAsync("http://localhost:5145/api/regist/register", jsonContent);

                var responseString = await response.Content.ReadAsStringAsync();

                Console.WriteLine($"Response Status: {response.StatusCode}");
                Console.WriteLine($"Response Content: {responseString}");
            }
            await Main(args);
        }
    }
}
